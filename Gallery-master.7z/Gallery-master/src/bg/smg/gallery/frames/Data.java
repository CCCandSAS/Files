package bg.smg.gallery.frames;

import java.util.ArrayList;
import java.util.List;

import bg.smg.gallery.model.User;

public class Data {
	public List<User> users = new ArrayList<User>();
}
